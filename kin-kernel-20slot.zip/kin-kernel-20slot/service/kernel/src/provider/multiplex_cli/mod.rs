//! One Claude OS process, N background kin-slot subagents, Rust MCP rendezvous.
//!
//! HTTP requests never share stdin. Jobs wake a ReadyBlocked slot via MCP
//! `slot_wait`; stream-json is demuxed by `parent_tool_use_id`.

pub mod bootstrap;
pub mod job_stream;
pub mod memory_guard;
pub mod continuation;
pub mod mcp_server;
pub mod pending_call;
pub mod replay;
pub mod scheduler;
pub mod slot;
pub mod stream_decoder;
pub mod supervisor;

use std::{
    collections::{HashMap, HashSet, VecDeque},
    env,
    path::PathBuf,
    sync::{
        Arc,
        atomic::{AtomicU32, AtomicU64, AtomicUsize, Ordering},
    },
    time::Duration,
};

use async_trait::async_trait;
use serde_json::{Value, json};
use tokio::sync::{Mutex, OnceCell};
use uuid::Uuid;

use crate::{
    error::KernelError,
    model::{ContentBlock, MessageContent, MessageRequest, MessageResponse, StopReason, Usage},
    provider::{ExecutionContext, Provider, ProviderCapabilities, StreamTx, job_event_channel},
    stream::StreamItem,
};

use self::{
    continuation::ContinuationToken,
    job_stream::JobStream,
    memory_guard::MemoryGuard,
    pending_call::{Job, JobOutcome, PendingCalls, SlotWaitPayload, new_id},
    scheduler::SlotScheduler,
    slot::{Slot, SlotPhase, SlotSnapshot},
};

#[derive(Clone)]
pub struct MultiplexConfig {
    pub slot_count: usize,
    pub simulate: bool,
    pub bin: PathBuf,
    pub mock_bin: bool,
    pub model: String,
    pub retire_after_turn: bool,
    pub max_jobs_per_slot: u32,
    pub slot_max_lifetime: Duration,
    pub session_idle_ttl: Duration,
    pub simulate_latency: Duration,
    pub continuation_ttl_secs: i64,
}

impl MultiplexConfig {
    pub fn from_env() -> Result<Self, Box<dyn std::error::Error>> {
        let slot_count = env::var("KIN_SLOTS_PER_WORKER")
            .ok()
            .and_then(|value| value.parse().ok())
            .unwrap_or(20)
            .clamp(1, 20);
        let bin = env::var("KIN_CLAUDE_BIN").map(PathBuf::from).unwrap_or_else(|_| {
            PathBuf::from(env::var("CARGO_MANIFEST_DIR").unwrap_or_else(|_| ".".into()))
                .join("../../scripts/kin-node-kernel/mock-claude.mjs")
        });
        let mock_bin = bin.to_string_lossy().contains("mock-claude");
        let simulate = env::var("KIN_MULTIPLEX_SIMULATE")
            .map(|value| value != "0")
            .unwrap_or(mock_bin);
        Ok(Self {
            slot_count,
            simulate,
            mock_bin,
            bin,
            model: env::var("KIN_CLI_MODEL").unwrap_or_else(|_| "claude-sonnet-5".into()),
            retire_after_turn: env::var("KIN_ISOLATION")
                .map(|value| value == "session-reset")
                .unwrap_or(false),
            max_jobs_per_slot: env::var("KIN_SLOT_MAX_JOBS")
                .ok()
                .and_then(|value| value.parse().ok())
                .unwrap_or(50),
            slot_max_lifetime: Duration::from_secs(
                env::var("KIN_SLOT_MAX_LIFETIME_SECS")
                    .ok()
                    .and_then(|value| value.parse().ok())
                    .unwrap_or(1800),
            ),
            session_idle_ttl: Duration::from_secs(
                env::var("KIN_SESSION_IDLE_TTL_SECS")
                    .ok()
                    .and_then(|value| value.parse().ok())
                    .unwrap_or(600),
            ),
            simulate_latency: Duration::from_millis(
                env::var("KIN_SIMULATE_LATENCY_MS")
                    .ok()
                    .and_then(|value| value.parse().ok())
                    .unwrap_or(40),
            ),
            continuation_ttl_secs: 600,
        })
    }
}

pub struct Runtime {
    pub process_generation: AtomicU64,
    pub pid: AtomicU32,
    secret: Vec<u8>,
    cfg: MultiplexConfig,
    slots: Mutex<Vec<Slot>>,
    sched: Mutex<SlotScheduler>,
    pending: Mutex<PendingCalls>,
    jobs: Mutex<HashMap<String, Job>>,
    events: Mutex<HashMap<String, StreamTx>>,
    parents: Mutex<HashMap<String, String>>,
    unassigned_parents: Mutex<VecDeque<String>>,
    issued: Mutex<HashMap<String, ContinuationToken>>,
    streamed: Mutex<HashSet<String>>,
    job_streams: Mutex<HashMap<String, JobStream>>,
    job_sizes: Mutex<HashMap<String, usize>>,
    pub memory: MemoryGuard,
    running: AtomicUsize,
    peak_running: AtomicUsize,
    ready: AtomicUsize,
}

impl Runtime {
    pub fn new(cfg: MultiplexConfig) -> Arc<Self> {
        let mut secret = vec![0u8; 32];
        for byte in &mut secret {
            *byte = rand_byte();
        }
        Arc::new(Self {
            process_generation: AtomicU64::new(1),
            pid: AtomicU32::new(0),
            secret,
            cfg,
            slots: Mutex::new(Vec::new()),
            sched: Mutex::new(SlotScheduler::new()),
            pending: Mutex::new(PendingCalls::new()),
            jobs: Mutex::new(HashMap::new()),
            events: Mutex::new(HashMap::new()),
            parents: Mutex::new(HashMap::new()),
            unassigned_parents: Mutex::new(VecDeque::new()),
            issued: Mutex::new(HashMap::new()),
            streamed: Mutex::new(HashSet::new()),
            job_streams: Mutex::new(HashMap::new()),
            job_sizes: Mutex::new(HashMap::new()),
            memory: MemoryGuard::from_env(),
            running: AtomicUsize::new(0),
            peak_running: AtomicUsize::new(0),
            ready: AtomicUsize::new(0),
        })
    }

    pub async fn start(self: &Arc<Self>) -> Result<(), KernelError> {
        if self.cfg.simulate {
            self.start_simulated().await
        } else {
            self.start_claude().await
        }
    }

    async fn start_simulated(self: &Arc<Self>) -> Result<(), KernelError> {
        self.pid.store(std::process::id(), Ordering::Relaxed);
        for index in 0..self.cfg.slot_count {
            let parent = format!("parent_{index}");
            let runtime = Arc::clone(self);
            tokio::spawn(async move {
                simulate_worker(runtime, parent).await;
            });
        }
        bootstrap::wait_ready(self, self.cfg.slot_count, Duration::from_secs(5)).await
    }

    async fn start_claude(self: &Arc<Self>) -> Result<(), KernelError> {
        let mcp_addr = mcp_server::spawn(
            Arc::clone(self),
            "127.0.0.1:0"
                .parse()
                .map_err(|err| KernelError::Provider(format!("{err}")))?,
        )
        .await?;
        tracing::info!(mcp = %mcp_addr, "kin mcp listening");
        let dir = PathBuf::from("/tmp/kin-cli/multiplex").join(Uuid::new_v4().to_string());
        let spec = supervisor::SpawnSpec {
            bin: self.cfg.bin.clone(),
            mock: self.cfg.mock_bin,
            model: self.cfg.model.clone(),
            slot_count: self.cfg.slot_count,
            mcp_url: format!("http://{mcp_addr}/mcp"),
            session_dir: dir,
        };
        let mut supervised = supervisor::spawn(&spec).await?;
        self.pid.store(supervised.pid, Ordering::Relaxed);
        self.memory.set_claude_pid(supervised.pid);
        let stdout = supervised
            .child
            .stdout
            .take()
            .ok_or_else(|| KernelError::Provider("claude stdout missing".into()))?;
        let mut stdin = supervised
            .child
            .stdin
            .take()
            .ok_or_else(|| KernelError::Provider("claude stdin missing".into()))?;
        let runtime = Arc::clone(self);
        tokio::spawn(async move {
            decode_stdout(runtime, stdout).await;
        });
        if let Some(stderr) = supervised.child.stderr.take() {
            tokio::spawn(async move {
                use tokio::io::{AsyncBufReadExt, BufReader};
                let mut lines = BufReader::new(stderr).lines();
                let path = "/tmp/kin-live/claude.multiplex.stderr.log";
                let mut file = tokio::fs::OpenOptions::new()
                    .create(true)
                    .append(true)
                    .open(path)
                    .await
                    .ok();
                while let Ok(Some(line)) = lines.next_line().await {
                    tracing::info!(target: "kin_kernel::claude", "{line}");
                    if let Some(file) = file.as_mut() {
                        use tokio::io::AsyncWriteExt;
                        let _ = file.write_all(line.as_bytes()).await;
                        let _ = file.write_all(b"\n").await;
                    }
                }
            });
        }
        bootstrap::write_root_prompt(&mut stdin, self.cfg.slot_count).await?;
        tokio::spawn(async move {
            // Keep stdin open (no more writes) and wait so kill_on_drop cannot
            // reap the process when this task would otherwise fall off the end.
            let _stdin = stdin;
            match supervised.child.wait().await {
                Ok(status) => tracing::warn!(%status, "claude process exited"),
                Err(err) => tracing::warn!(%err, "claude wait failed"),
            }
        });
        tracing::info!(pid = supervised.pid, "claude supervisor alive");
        let wait = Duration::from_secs((45 + 8 * self.cfg.slot_count as u64).min(240));
        bootstrap::wait_ready(self, self.cfg.slot_count, wait).await
    }

    pub fn ready_slots(&self) -> usize {
        self.ready.load(Ordering::Relaxed)
    }

    pub async fn snapshots(&self) -> Vec<SlotSnapshot> {
        self.slots
            .lock()
            .await
            .iter()
            .map(|slot| SlotSnapshot {
                id: slot.id.clone(),
                phase: slot.phase,
                parent_tool_use_id: slot.parent_tool_use_id.clone(),
                session_id: slot.session_id.clone(),
                tenant_id: slot.tenant_id.clone(),
                jobs_completed: slot.jobs_completed,
            })
            .collect()
    }

    pub fn peak_running(&self) -> usize {
        self.peak_running.load(Ordering::Relaxed)
    }

    pub fn bump_generation(&self) -> u64 {
        self.process_generation.fetch_add(1, Ordering::AcqRel) + 1
    }

    pub async fn mcp_slot_wait(&self, args: Value) -> Result<Value, KernelError> {
        let hinted = args
            .get("slot_id")
            .and_then(Value::as_str)
            .map(ToOwned::to_owned);
        let slot_id = self.register_or_get_slot(hinted).await;
        let rx = {
            let mut pending = self.pending.lock().await;
            pending.register_slot_wait(&slot_id)
        };
        {
            let mut slots = self.slots.lock().await;
            if let Some(slot) = slots.iter_mut().find(|slot| slot.id == slot_id) {
                if slot.phase != SlotPhase::Dead
                    && slot.phase != SlotPhase::Draining
                    && slot.phase != SlotPhase::ReadyBlocked
                {
                    slot.phase = SlotPhase::ReadyBlocked;
                    slot.job_id = None;
                }
            }
            if self.sched.lock().await.enqueue_ready(slot_id.clone()) {
                self.ready.fetch_add(1, Ordering::Relaxed);
            }
        }
        match rx.await {
            Ok(SlotWaitPayload::Job(job)) => Ok(json!({
                "type": "job",
                "job_id": job.job_id,
                "slot_id": job.slot_id,
                "session_id": job.session_id,
                "model": job.request.model,
                "max_tokens": job.request.max_tokens,
                "stream": job.request.stream,
                "system": job.request.system,
                "thinking": job.request.thinking,
                "tool_choice": job.request.tool_choice,
                "metadata": job.request.metadata,
                "temperature": job.request.temperature,
                "top_p": job.request.top_p,
                "top_k": job.request.top_k,
                "stop_sequences": job.request.stop_sequences,
                "betas": job.request.betas,
                "messages": job.request.messages,
                "tools": job.request.tools,
                "extra": job.request.extra,
                "request": job.request
            })),
            Ok(SlotWaitPayload::Retire) => Ok(json!({ "type": "retire" })),
            Err(_) => Err(KernelError::Provider("slot_wait cancelled".into())),
        }
    }

    pub async fn mcp_client_tool(&self, args: Value) -> Result<Value, KernelError> {
        let job_id = args
            .get("job_id")
            .and_then(Value::as_str)
            .ok_or_else(|| KernelError::InvalidRequest("client_tool needs job_id".into()))?
            .to_string();
        let name = args
            .get("name")
            .and_then(Value::as_str)
            .unwrap_or("tool")
            .to_string();
        let input = args.get("input").cloned().unwrap_or_else(|| json!({}));
        let tool_id = args
            .get("client_tool_use_id")
            .and_then(Value::as_str)
            .map(ToOwned::to_owned)
            .unwrap_or_else(|| new_id("toolu"));
        let job = self
            .jobs
            .lock()
            .await
            .get(&job_id)
            .cloned()
            .ok_or(KernelError::ContinuationLost)?;
        {
            let mut slots = self.slots.lock().await;
            let slot = slots
                .iter_mut()
                .find(|slot| slot.id == job.slot_id)
                .ok_or(KernelError::ContinuationLost)?;
            if !slot.cas(SlotPhase::Running, SlotPhase::WaitingTool) {
                return Err(KernelError::ContinuationMismatch("slot not running".into()));
            }
        }
        let generation = self.process_generation.load(Ordering::Relaxed);
        let (token, encoded) = ContinuationToken::issue(
            generation,
            &job.slot_id,
            &job.job_id,
            &job.session_id,
            &tool_id,
            self.cfg.continuation_ttl_secs,
            &self.secret,
        );
        self.issued.lock().await.insert(token.nonce.clone(), token);
        let tool_block = json!({
            "type": "tool_use",
            "id": tool_id.clone(),
            "name": name.clone(),
            "input": input.clone()
        });
        let events = {
            let mut streams = self.job_streams.lock().await;
            match streams.get_mut(&job_id) {
                Some(stream) => {
                    let mut events = stream.emit_complete_block(&tool_block);
                    events.extend(stream.finish("tool_use", json!({})));
                    events
                }
                None => vec![json!({
                    "type": "content_block_start",
                    "index": 0,
                    "content_block": {
                        "type": "tool_use",
                        "id": &tool_id,
                        "name": &name,
                        "input": &input
                    }
                })],
            }
        };
        for event in events {
            self.emit(&job_id, StreamItem::Event(event)).await;
        }
        let response = MessageResponse {
            id: format!("msg_{}", self.pid.load(Ordering::Relaxed)),
            r#type: "message",
            role: "assistant",
            model: job.request.model.clone(),
            content: vec![ContentBlock::ToolUse {
                id: tool_id.clone(),
                name,
                input,
            }],
            stop_reason: StopReason::ToolUse,
            usage: Usage::default(),
        };
        self.emit(&job_id, StreamItem::Finished(response)).await;
        let rx = {
            let mut pending = self.pending.lock().await;
            pending.register_client_tool(&job_id, Some(tool_id.as_str()))
        };
        let result = rx.await.map_err(|_| KernelError::ContinuationLost)?;
        {
            let mut slots = self.slots.lock().await;
            if let Some(slot) = slots.iter_mut().find(|slot| slot.id == job.slot_id) {
                let _ = slot.cas(SlotPhase::WaitingTool, SlotPhase::Running);
            }
        }
        let _ = encoded;
        Ok(result)
    }

    pub async fn mcp_kin_done(&self, args: Value) -> Result<Value, KernelError> {
        let job_id = args
            .get("job_id")
            .and_then(Value::as_str)
            .ok_or_else(|| KernelError::InvalidRequest("kin_done needs job_id".into()))?;
        let fallback = args
            .get("fallback_content")
            .or_else(|| args.get("text"))
            .and_then(Value::as_str)
            .unwrap_or("")
            .to_string();
        let stop = args
            .get("stop_reason")
            .and_then(Value::as_str)
            .unwrap_or("end_turn")
            .to_string();
        let usage = args.get("usage").cloned().unwrap_or_else(|| json!({}));
        self.complete_job(job_id, fallback, false, &stop, usage).await?;
        Ok(json!({ "ok": true }))
    }

    pub async fn mcp_kin_fail(&self, args: Value) -> Result<Value, KernelError> {
        let job_id = args
            .get("job_id")
            .and_then(Value::as_str)
            .ok_or_else(|| KernelError::InvalidRequest("kin_fail needs job_id".into()))?;
        let error = args
            .get("error")
            .and_then(Value::as_str)
            .unwrap_or("slot failed")
            .to_string();
        let retire = args.get("retire").and_then(Value::as_bool).unwrap_or(true);
        self.complete_job(job_id, error, true, "refusal", json!({})).await?;
        if retire {
            if let Some(job) = self.jobs.lock().await.get(job_id).cloned() {
                self.retire_slot(&job.slot_id).await;
            }
        }
        Ok(json!({ "ok": true }))
    }

    async fn complete_job(
        &self,
        job_id: &str,
        fallback: String,
        is_error: bool,
        stop_reason: &str,
        usage: Value,
    ) -> Result<(), KernelError> {
        let job = self
            .jobs
            .lock()
            .await
            .get(job_id)
            .cloned()
            .ok_or(KernelError::ContinuationLost)?;
        let mut stream = self
            .job_streams
            .lock()
            .await
            .remove(job_id)
            .unwrap_or_else(JobStream::new);
        for event in stream.fallback_text(&fallback) {
            self.emit(job_id, StreamItem::Event(event)).await;
        }
        for event in stream.finish(stop_reason, usage) {
            self.emit(job_id, StreamItem::Event(event)).await;
        }
        let text = if stream.text.is_empty() { fallback.clone() } else { stream.text.clone() };
        let response = MessageResponse {
            id: format!("msg_{}", self.pid.load(Ordering::Relaxed)),
            r#type: "message",
            role: "assistant",
            model: job.request.model.clone(),
            content: vec![ContentBlock::Text { text: text.clone(), cache_control: None }],
            stop_reason: if is_error { StopReason::Refusal } else { StopReason::EndTurn },
            usage: Usage::default(),
        };
        self.emit(job_id, StreamItem::Finished(response)).await;
        self.pending.lock().await.finish_job(job_id, JobOutcome { text, is_error })?;
        self.running.fetch_update(Ordering::Relaxed, Ordering::Relaxed, |n| Some(n.saturating_sub(1))).ok();
        if let Some(size) = self.job_sizes.lock().await.remove(job_id) {
            self.memory.end(size);
        }
        self.streamed.lock().await.remove(job_id);
        let retire = {
            let mut slots = self.slots.lock().await;
            if let Some(slot) = slots.iter_mut().find(|slot| slot.id == job.slot_id) {
                slot.jobs_completed = slot.jobs_completed.saturating_add(1);
                self.cfg.retire_after_turn
                    || slot.should_retire(
                        self.cfg.max_jobs_per_slot,
                        self.cfg.slot_max_lifetime,
                        self.cfg.session_idle_ttl,
                    )
            } else {
                false
            }
        };
        if retire {
            self.retire_slot(&job.slot_id).await;
        }
        Ok(())
    }

    async fn retire_idle(&self) {
        let ids: Vec<String> = {
            let slots = self.slots.lock().await;
            slots
                .iter()
                .filter(|slot| {
                    slot.phase == SlotPhase::ReadyBlocked
                        && slot.should_retire(
                            self.cfg.max_jobs_per_slot,
                            self.cfg.slot_max_lifetime,
                            self.cfg.session_idle_ttl,
                        )
                })
                .map(|slot| slot.id.clone())
                .collect()
        };
        for id in ids {
            self.retire_slot(&id).await;
        }
    }

    async fn retire_slot(&self, slot_id: &str) {
        {
            let mut slots = self.slots.lock().await;
            if let Some(slot) = slots.iter_mut().find(|slot| slot.id == slot_id) {
                slot.retire();
            }
        }
        self.sched.lock().await.forget(slot_id);
        let mut pending = self.pending.lock().await;
        let _ = pending.wake_slot(slot_id, SlotWaitPayload::Retire);
    }

    async fn register_or_get_slot(&self, hinted: Option<String>) -> String {
        let mut slots = self.slots.lock().await;
        if let Some(id) = hinted.as_ref()
            && let Some(slot) = slots.iter().find(|slot| slot.id == *id)
            && slot.phase != SlotPhase::Dead
            && slot.phase != SlotPhase::Draining
        {
            return id.clone();
        }
        let id = hinted.unwrap_or_else(|| new_id("slot"));
        let mut slot = Slot::new(&id);
        if let Some(parent) = self.unassigned_parents.lock().await.pop_front() {
            slot.parent_tool_use_id = Some(parent.clone());
            self.parents.lock().await.insert(parent, id.clone());
        }
        slots.push(slot);
        id
    }

    pub async fn note_agent_spawn(&self, tool_use_id: String) {
        let mut slots = self.slots.lock().await;
        if let Some(slot) = slots
            .iter_mut()
            .find(|slot| slot.parent_tool_use_id.is_none() && slot.phase != SlotPhase::Dead)
        {
            slot.parent_tool_use_id = Some(tool_use_id.clone());
            self.parents.lock().await.insert(tool_use_id, slot.id.clone());
            return;
        }
        drop(slots);
        self.unassigned_parents.lock().await.push_back(tool_use_id);
    }

    pub async fn handle_cli_frame(&self, frame: Value) {
        match stream_decoder::decode(&frame) {
            stream_decoder::Decoded::AgentSpawn { tool_use_id } => {
                self.note_agent_spawn(tool_use_id).await;
            }
            stream_decoder::Decoded::Routed {
                parent_tool_use_id,
                ..
            } => {
                let slot_id = self.parents.lock().await.get(&parent_tool_use_id).cloned();
                let Some(slot_id) = slot_id else {
                    return;
                };
                let job_id = {
                    let slots = self.slots.lock().await;
                    slots
                        .iter()
                        .find(|slot| slot.id == slot_id)
                        .and_then(|slot| slot.job_id.clone())
                };
                let Some(job_id) = job_id else {
                    return;
                };
                let events = {
                    let mut streams = self.job_streams.lock().await;
                    match streams.get_mut(&job_id) {
                        Some(stream) => stream.ingest(&frame),
                        None => Vec::new(),
                    }
                };
                for event in events {
                    self.emit(&job_id, StreamItem::Event(event)).await;
                }
            }
            stream_decoder::Decoded::Root => {}
        }
    }

    async fn emit(&self, job_id: &str, item: StreamItem) {
        if let StreamItem::Event(ref event) = item {
            if event.get("type").and_then(Value::as_str) == Some("content_block_delta")
                && event.pointer("/delta/type").and_then(Value::as_str) == Some("text_delta")
            {
                self.streamed.lock().await.insert(job_id.to_string());
            }
        }
        let finished = matches!(item, StreamItem::Finished(_));
        let tx = {
            let mut events = self.events.lock().await;
            if finished {
                events.remove(job_id)
            } else {
                events.get(job_id).cloned()
            }
        };
        if let Some(tx) = tx {
            if tx.try_send(Ok(item)).is_err() && finished {
                tracing::warn!(job_id, "client channel full or closed on finish");
            }
        }
    }

    pub async fn submit(
        &self,
        request: MessageRequest,
        context: ExecutionContext,
        tx: StreamTx,
    ) -> Result<(), KernelError> {
        if context.resumed {
            return self.resume(request, context, tx).await;
        }
        let request_bytes = serde_json::to_vec(&request).map(|v| v.len()).unwrap_or(0);
        self.memory.admit(request_bytes)?;
        self.retire_idle().await;
        let generation = self.process_generation.load(Ordering::Relaxed);
        let mut slots = self.slots.lock().await;
        let mut sched = self.sched.lock().await;
        let slot_id = sched.pick(&mut slots, &context.tenant_id, &context.session_id)?;
        self.ready.fetch_update(Ordering::Relaxed, Ordering::Relaxed, |n| Some(n.saturating_sub(1))).ok();
        let job_id = new_id("job");
        let slot = slots
            .iter_mut()
            .find(|slot| slot.id == slot_id)
            .ok_or(KernelError::NoCapacity)?;
        if !slot.bind_job(&context.tenant_id, &context.session_id, &job_id) {
            return Err(KernelError::NoCapacity);
        }
        drop(sched);
        drop(slots);
        let job = Job {
            job_id: job_id.clone(),
            tenant_id: context.tenant_id,
            session_id: context.session_id,
            slot_id: slot_id.clone(),
            generation,
            request,
        };
        self.jobs.lock().await.insert(job_id.clone(), job.clone());
        self.events.lock().await.insert(job_id.clone(), tx);
        self.job_streams.lock().await.insert(job_id.clone(), JobStream::new());
        self.job_sizes.lock().await.insert(job_id.clone(), request_bytes);
        self.memory.begin(request_bytes);
        let n = self.running.fetch_add(1, Ordering::Relaxed) + 1;
        self.peak_running.fetch_max(n, Ordering::Relaxed);
        let msg_id = format!("msg_{job_id}");
        self.emit(
            &job_id,
            StreamItem::Event(JobStream::message_start(&job.request.model, &msg_id)),
        )
        .await;
        self.pending
            .lock()
            .await
            .wake_slot(&slot_id, SlotWaitPayload::Job(job))?;
        Ok(())
    }

    async fn resume(
        &self,
        request: MessageRequest,
        context: ExecutionContext,
        tx: StreamTx,
    ) -> Result<(), KernelError> {
        let generation = self.process_generation.load(Ordering::Relaxed);
        let slots = self.slots.lock().await;
        let slot = slots
            .iter()
            .find(|slot| slot.session_id.as_deref() == Some(context.session_id.as_str()))
            .ok_or(KernelError::ContinuationLost)?;
        if slot.phase != SlotPhase::WaitingTool {
            return Err(KernelError::ContinuationLost);
        }
        let job_id = slot.job_id.clone().ok_or(KernelError::ContinuationLost)?;
        drop(slots);
        let job = self
            .jobs
            .lock()
            .await
            .get(&job_id)
            .cloned()
            .ok_or(KernelError::ContinuationLost)?;
        if job.generation != generation || job.tenant_id != context.tenant_id {
            return Err(KernelError::ContinuationLost);
        }
        self.events.lock().await.insert(job_id.clone(), tx);
        self.job_streams
            .lock()
            .await
            .insert(job_id.clone(), JobStream::new());
        let msg_id = format!("msg_{job_id}");
        self.emit(
            &job_id,
            StreamItem::Event(JobStream::message_start(&job.request.model, &msg_id)),
        )
        .await;
        let results = tool_results(&request);
        self.pending
            .lock()
            .await
            .complete_client_tools(&job_id, results)?;
        Ok(())
    }

    pub fn pid(&self) -> u32 {
        self.pid.load(Ordering::Relaxed)
    }
}

fn tool_results(request: &MessageRequest) -> Vec<(String, Value)> {
    let mut out = Vec::new();
    for message in &request.messages {
        if let MessageContent::Blocks(blocks) = &message.content {
            for block in blocks {
                if let ContentBlock::ToolResult {
                    tool_use_id,
                    content,
                    is_error,
                } = block
                {
                    out.push((
                        tool_use_id.clone(),
                        json!({
                            "tool_use_id": tool_use_id,
                            "content": content,
                            "is_error": is_error
                        }),
                    ));
                }
            }
        }
    }
    out
}

fn latest_text(request: &MessageRequest) -> String {
    for message in request.messages.iter().rev() {
        if message.role != "user" {
            continue;
        }
        match &message.content {
            MessageContent::Text(text) => return text.clone(),
            MessageContent::Blocks(blocks) => {
                let mut out = String::new();
                for block in blocks {
                    if let ContentBlock::Text { text, .. } = block {
                        out.push_str(text);
                    }
                }
                if !out.is_empty() {
                    return out;
                }
            }
        }
    }
    String::new()
}

fn rand_byte() -> u8 {
    Uuid::new_v4().as_bytes()[0]
}

async fn simulate_worker(runtime: Arc<Runtime>, parent: String) {
    runtime.note_agent_spawn(parent.clone()).await;
    let slot_id = runtime.register_or_get_slot(None).await;
    runtime
        .parents
        .lock()
        .await
        .insert(parent.clone(), slot_id.clone());
    {
        let mut slots = runtime.slots.lock().await;
        if let Some(slot) = slots.iter_mut().find(|slot| slot.id == slot_id) {
            slot.parent_tool_use_id = Some(parent.clone());
        }
    }
    loop {
        let payload = match runtime.mcp_slot_wait(json!({ "slot_id": slot_id })).await {
            Ok(value) => value,
            Err(_) => break,
        };
        if payload.get("type").and_then(Value::as_str) == Some("retire") {
            break;
        }
        let job_id = payload
            .get("job_id")
            .and_then(Value::as_str)
            .unwrap_or("")
            .to_string();
        let job = {
            let jobs = runtime.jobs.lock().await;
            jobs.get(&job_id).cloned()
        };
        let Some(job) = job else {
            continue;
        };
        let text = latest_text(&job.request);
        tokio::time::sleep(runtime.cfg.simulate_latency).await;
        if text.contains("[web_search]") {
            let ws = json!({
                "type": "assistant",
                "parent_tool_use_id": parent,
                "message": { "content": [{
                    "type": "tool_use",
                    "id": "toolu_ws_sim",
                    "name": "WebSearch",
                    "input": { "query": text }
                }]}
            });
            runtime.handle_cli_frame(ws).await;
            let result = json!({
                "type": "user",
                "parent_tool_use_id": parent,
                "message": { "content": [{
                    "type": "tool_result",
                    "tool_use_id": "toolu_ws_sim",
                    "content": "Web search results for query"
                }]}
            });
            runtime.handle_cli_frame(result).await;
            let answer = json!({
                "type": "assistant",
                "parent_tool_use_id": parent,
                "message": { "content": [{ "type": "text", "text": "search-complete" }] }
            });
            runtime.handle_cli_frame(answer).await;
            let _ = runtime
                .mcp_kin_done(json!({
                    "job_id": job.job_id,
                    "stop_reason": "end_turn",
                    "usage": { "web_search_requests": 1 },
                    "fallback_content": "DUPLICATE_FROM_KIN_DONE"
                }))
                .await;
        } else if let Some(tool) = text
            .split("[use_tool:")
            .nth(1)
            .and_then(|part| part.split(']').next())
        {
            let _ = runtime
                .mcp_client_tool(json!({
                    "job_id": job.job_id,
                    "name": tool,
                    "input": { "echo": true }
                }))
                .await;
            let _ = runtime
                .mcp_kin_done(json!({
                    "job_id": job.job_id,
                    "text": format!("tool finished for {tool}")
                }))
                .await;
        } else {
            let reply = format!("slot {} :: {text}", &slot_id[..8.min(slot_id.len())]);
            let frame = json!({
                "type": "assistant",
                "parent_tool_use_id": parent,
                "message": { "role": "assistant", "content": [{ "type": "text", "text": reply }] }
            });
            runtime.handle_cli_frame(frame).await;
            let _ = runtime
                .mcp_kin_done(json!({
                    "job_id": job.job_id,
                    "stop_reason": "end_turn",
                    "usage": { "output_tokens": 8 },
                    "fallback_content": reply,
                    "text": reply
                }))
                .await;
        }
    }
}

async fn decode_stdout(
    runtime: Arc<Runtime>,
    stdout: impl tokio::io::AsyncRead + Unpin,
) {
    use tokio::io::{AsyncBufReadExt, BufReader};
    let mut lines = BufReader::new(stdout).lines();
    let mut job_bytes: HashMap<String, usize> = HashMap::new();
    let mut dump = tokio::fs::OpenOptions::new()
        .create(true)
        .append(true)
        .open("/tmp/kin-live/claude.multiplex.stdout.log")
        .await
        .ok();
    while let Ok(Some(line)) = lines.next_line().await {
        if let Some(file) = dump.as_mut() {
            use tokio::io::AsyncWriteExt;
            let _ = file.write_all(line.as_bytes()).await;
            let _ = file.write_all(b"\n").await;
        }
        if line.len() > stream_decoder::MAX_LINE_BYTES {
            continue;
        }
        let Ok(frame) = serde_json::from_str::<Value>(&line) else {
            continue;
        };
        if let Some(parent) = stream_decoder::parent_id(&frame) {
            let used = job_bytes.entry(parent.to_string()).or_insert(0);
            *used = used.saturating_add(line.len());
            if *used > stream_decoder::MAX_JOB_BYTES {
                continue;
            }
        }
        runtime.handle_cli_frame(frame).await;
    }
}

pub struct MultiplexCliProvider {
    cfg: MultiplexConfig,
    runtime: OnceCell<Arc<Runtime>>,
}

impl MultiplexCliProvider {
    pub fn from_env() -> Result<Self, Box<dyn std::error::Error>> {
        Ok(Self {
            cfg: MultiplexConfig::from_env()?,
            runtime: OnceCell::new(),
        })
    }

    pub fn simulated(slot_count: usize) -> Self {
        Self {
            cfg: MultiplexConfig {
                slot_count,
                simulate: true,
                bin: PathBuf::from("simulated"),
                mock_bin: true,
                model: "claude-sonnet-5".into(),
                retire_after_turn: false,
                max_jobs_per_slot: 32,
                slot_max_lifetime: Duration::from_secs(1800),
                session_idle_ttl: Duration::from_secs(600),
                simulate_latency: Duration::from_millis(60),
                continuation_ttl_secs: 600,
            },
            runtime: OnceCell::new(),
        }
    }

    async fn runtime(&self) -> Result<&Arc<Runtime>, KernelError> {
        self.runtime
            .get_or_try_init(|| async {
                let runtime = Runtime::new(MultiplexConfig {
                    slot_count: self.cfg.slot_count,
                    simulate: self.cfg.simulate,
                    bin: self.cfg.bin.clone(),
                    mock_bin: self.cfg.mock_bin,
                    model: self.cfg.model.clone(),
                    retire_after_turn: self.cfg.retire_after_turn,
                    max_jobs_per_slot: self.cfg.max_jobs_per_slot,
                    slot_max_lifetime: self.cfg.slot_max_lifetime,
                    session_idle_ttl: self.cfg.session_idle_ttl,
                    simulate_latency: self.cfg.simulate_latency,
                    continuation_ttl_secs: self.cfg.continuation_ttl_secs,
                });
                runtime.start().await?;
                Ok(runtime)
            })
            .await
    }
}

#[async_trait]
impl Provider for MultiplexCliProvider {
    fn name(&self) -> &'static str {
        "local_cli"
    }

    async fn boot(&self) -> Result<(), KernelError> {
        self.runtime().await.map(|_| ())
    }

    fn capabilities(&self) -> ProviderCapabilities {
        ProviderCapabilities {
            streaming: true,
            resume: true,
            multiplex_slots: true,
            native_tool_wait: true,
            cancel_receipt: true,
        }
    }

    fn session_pid(&self, _session_id: &str) -> Option<u32> {
        self.runtime.get().map(|runtime| runtime.pid())
    }

    fn memory_snapshot(&self) -> Option<serde_json::Value> {
        self.runtime.get().map(|runtime| {
            serde_json::to_value(runtime.memory.snapshot()).unwrap_or(serde_json::Value::Null)
        })
    }

    async fn execute_stream(
        &self,
        request: &MessageRequest,
        context: &ExecutionContext,
    ) -> Result<crate::provider::StreamRx, KernelError>
    {
        let runtime = self.runtime().await?;
        let (tx, rx) = job_event_channel();
        runtime
            .submit(request.clone(), context.clone(), tx)
            .await?;
        Ok(rx)
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::model::{Message, ToolDefinition};
    use crate::provider::stream_channel;
    use tokio::time::timeout;

    fn ctx(session: &str, resumed: bool) -> ExecutionContext {
        ExecutionContext {
            tenant_id: "demo".into(),
            session_id: session.into(),
            worker_id: "runtime-00".into(),
            worker_generation: 1,
            resumed,
        }
    }

    fn text_request(text: &str) -> MessageRequest {
        MessageRequest {
            model: "claude-sonnet-5".into(),
            messages: vec![Message {
                role: "user".into(),
                content: MessageContent::Text(text.into()),
                tool_call_id: None,
                tool_calls: Vec::new(),
            }],
            tools: vec![ToolDefinition {
                name: "echo".into(),
                description: "echo".into(),
                input_schema: json!({"type":"object"}),
                cache_control: None,
                tool_type: None,
                extra: Default::default(),
            }],
            max_tokens: 128,
            stream: false,
            ..MessageRequest::default()
        }
    }

    async fn collect(
        provider: &MultiplexCliProvider,
        request: MessageRequest,
        context: ExecutionContext,
    ) -> Result<MessageResponse, KernelError> {
        let rx = provider.execute_stream(&request, &context).await?;
        crate::provider::collect_stream(rx).await
    }

    #[tokio::test(flavor = "multi_thread", worker_threads = 4)]
    async fn one_pid_five_parallel_slots() {
        let shared = MultiplexCliProvider::simulated(5);
        shared.runtime().await.expect("start");
        let pid = shared.session_pid("any").expect("pid");
        let mut joins = Vec::new();
        for index in 0..5 {
            let request = text_request(&format!("hello {index}"));
            let context = ctx(&format!("sess-{index}"), false);
            let runtime = Arc::clone(shared.runtime.get().unwrap());
            joins.push(tokio::spawn(async move {
                let (tx, rx) = stream_channel();
                runtime.submit(request, context, tx).await.unwrap();
                crate::provider::collect_stream(rx).await
            }));
        }
        let mut texts = Vec::new();
        for join in joins {
            let response = timeout(Duration::from_secs(5), join)
                .await
                .unwrap()
                .unwrap()
                .unwrap();
            assert!(matches!(response.stop_reason, StopReason::EndTurn));
            assert_eq!(shared.session_pid("x").unwrap(), pid);
            if let ContentBlock::Text { text, .. } = &response.content[0] {
                texts.push(text.clone());
            }
        }
        assert_eq!(texts.len(), 5);
        assert!(shared.runtime.get().unwrap().peak_running() >= 2);
        let parents: Vec<_> = shared
            .runtime
            .get()
            .unwrap()
            .snapshots()
            .await
            .into_iter()
            .filter_map(|slot| slot.parent_tool_use_id)
            .collect();
        let unique: std::collections::HashSet<_> = parents.iter().cloned().collect();
        assert_eq!(unique.len(), 5);
    }

    #[tokio::test(flavor = "multi_thread", worker_threads = 4)]
    async fn two_tool_calls_resume_independently() {
        let provider = MultiplexCliProvider::simulated(2);
        let first = collect(
            &provider,
            text_request("please [use_tool:echo] now"),
            ctx("sess-tool-a", false),
        )
        .await
        .unwrap();
        let second = collect(
            &provider,
            text_request("please [use_tool:echo] now"),
            ctx("sess-tool-b", false),
        )
        .await
        .unwrap();
        assert!(matches!(first.stop_reason, StopReason::ToolUse));
        assert!(matches!(second.stop_reason, StopReason::ToolUse));
        let id_a = match &first.content[0] {
            ContentBlock::ToolUse { id, .. } => id.clone(),
            _ => panic!("tool a"),
        };
        let id_b = match &second.content[0] {
            ContentBlock::ToolUse { id, .. } => id.clone(),
            _ => panic!("tool b"),
        };
        assert_ne!(id_a, id_b);
        let resume = |id: String| MessageRequest {
            model: "claude-sonnet-5".into(),
            messages: vec![Message {
                role: "user".into(),
                content: MessageContent::Blocks(vec![ContentBlock::ToolResult {
                    tool_use_id: id,
                    content: json!("ok"),
                    is_error: false,
                }]),
                tool_call_id: None,
                tool_calls: Vec::new(),
            }],
            max_tokens: 32,
            stream: false,
            ..MessageRequest::default()
        };
        let a = collect(&provider, resume(id_a), ctx("sess-tool-a", true))
            .await
            .unwrap();
        let b = collect(&provider, resume(id_b), ctx("sess-tool-b", true))
            .await
            .unwrap();
        assert!(matches!(a.stop_reason, StopReason::EndTurn));
        assert!(matches!(b.stop_reason, StopReason::EndTurn));
    }

    #[tokio::test(flavor = "multi_thread", worker_threads = 2)]
    async fn stale_generation_is_continuation_lost() {
        let provider = MultiplexCliProvider::simulated(1);
        let _ = collect(
            &provider,
            text_request("please [use_tool:echo] now"),
            ctx("sess-gen", false),
        )
        .await
        .unwrap();
        provider.runtime.get().unwrap().bump_generation();
        let err = collect(
            &provider,
            text_request("ignored"),
            ctx("sess-gen", true),
        )
        .await
        .unwrap_err();
        assert!(matches!(err, KernelError::ContinuationLost));
    }

    #[tokio::test(flavor = "multi_thread", worker_threads = 4)]
    async fn one_pid_twenty_parallel_slots() {
        let shared = MultiplexCliProvider::simulated(20);
        shared.runtime().await.expect("start");
        let pid = shared.session_pid("any").expect("pid");
        let started = std::time::Instant::now();
        let mut joins = Vec::new();
        for index in 0..20 {
            let request = text_request(&format!("hello {index}"));
            let context = ctx(&format!("sess-20-{index}"), false);
            let runtime = Arc::clone(shared.runtime.get().unwrap());
            joins.push(tokio::spawn(async move {
                let (tx, rx) = stream_channel();
                runtime.submit(request, context, tx).await.unwrap();
                crate::provider::collect_stream(rx).await
            }));
        }
        let mut texts = Vec::new();
        for join in joins {
            let response = timeout(Duration::from_secs(5), join)
                .await
                .unwrap()
                .unwrap()
                .unwrap();
            assert_eq!(shared.session_pid("x").unwrap(), pid);
            if let ContentBlock::Text { text, .. } = &response.content[0] {
                texts.push(text.clone());
            }
        }
        let elapsed = started.elapsed();
        assert_eq!(texts.len(), 20);
        let unique: std::collections::HashSet<_> = texts.into_iter().collect();
        assert_eq!(unique.len(), 20, "outputs must not mix across slots");
        assert!(
            elapsed < Duration::from_millis(800),
            "20 slots should overlap, elapsed={elapsed:?}"
        );
        assert!(shared.runtime.get().unwrap().peak_running() >= 10);
        let parents: Vec<_> = shared
            .runtime
            .get()
            .unwrap()
            .snapshots()
            .await
            .into_iter()
            .filter_map(|slot| slot.parent_tool_use_id)
            .collect();
        let unique_parents: std::collections::HashSet<_> = parents.iter().cloned().collect();
        assert_eq!(unique_parents.len(), 20);
    }

    #[tokio::test]
    async fn memory_guard_rejects_when_rss_is_over_limit() {
        let provider = MultiplexCliProvider::simulated(2);
        provider.runtime().await.expect("start");
        provider
            .runtime
            .get()
            .unwrap()
            .memory
            .set_rss_override(4 * crate::provider::multiplex_cli::memory_guard::GIB);
        let err = collect(&provider, text_request("hello"), ctx("sess-oom", false))
            .await
            .unwrap_err();
        assert!(matches!(err, KernelError::Overloaded { .. }));
    }

    #[tokio::test(flavor = "multi_thread", worker_threads = 2)]
    async fn message_start_arrives_before_slot_finishes() {
        let provider = MultiplexCliProvider::simulated(1);
        let rx = provider
            .execute_stream(&text_request("hello stream"), &ctx("sess-stream", false))
            .await
            .unwrap();
        let mut rx = rx;
        let first = timeout(Duration::from_millis(40), rx.recv())
            .await
            .expect("message_start should not wait for the slot")
            .unwrap()
            .unwrap();
        match first {
            StreamItem::Event(event) => {
                assert_eq!(event.get("type").and_then(Value::as_str), Some("message_start"));
            }
            other => panic!("expected message_start, got {other:?}"),
        }
    }

    #[tokio::test(flavor = "multi_thread", worker_threads = 2)]
    async fn stdout_text_is_one_block_not_fake_tokens() {
        let provider = MultiplexCliProvider::simulated(1);
        let rx = provider
            .execute_stream(&text_request("hello stream"), &ctx("sess-block", false))
            .await
            .unwrap();
        let mut deltas = Vec::new();
        let mut types = Vec::new();
        let mut rx = rx;
        while let Some(item) = rx.recv().await {
            match item.unwrap() {
                StreamItem::Event(event) => {
                    types.push(event.get("type").and_then(Value::as_str).unwrap_or("").to_string());
                    if event.pointer("/delta/type").and_then(Value::as_str) == Some("text_delta") {
                        deltas.push(event["delta"]["text"].as_str().unwrap_or("").to_string());
                    }
                }
                StreamItem::Finished(_) => {}
            }
        }
        assert_eq!(types.first().map(String::as_str), Some("message_start"));
        assert_eq!(deltas.len(), 1, "do not fake-chunk: {deltas:?}");
        assert!(deltas[0].contains("hello stream"), "{}", deltas[0]);
        assert!(types.iter().any(|t| t == "message_delta"));
        assert!(types.iter().any(|t| t == "message_stop"));
    }

    #[tokio::test(flavor = "multi_thread", worker_threads = 2)]
    async fn web_search_frames_are_forwarded() {
        let provider = MultiplexCliProvider::simulated(1);
        let rx = provider
            .execute_stream(&text_request("please [web_search] now"), &ctx("sess-ws", false))
            .await
            .unwrap();
        let mut block_types = Vec::new();
        let mut deltas = Vec::new();
        let mut rx = rx;
        while let Some(item) = rx.recv().await {
            if let StreamItem::Event(event) = item.unwrap() {
                if event.get("type").and_then(Value::as_str) == Some("content_block_start") {
                    block_types.push(
                        event["content_block"]["type"]
                            .as_str()
                            .unwrap_or("")
                            .to_string(),
                    );
                }
                if event.pointer("/delta/type").and_then(Value::as_str) == Some("text_delta") {
                    deltas.push(event["delta"]["text"].as_str().unwrap_or("").to_string());
                }
            }
        }
        assert!(
            block_types.contains(&"server_tool_use".to_string()),
            "{block_types:?}"
        );
        assert!(
            block_types.contains(&"web_search_tool_result".to_string()),
            "{block_types:?}"
        );
        assert!(block_types.contains(&"text".to_string()), "{block_types:?}");
        assert_eq!(deltas, vec!["search-complete".to_string()]);
        assert!(
            !deltas.iter().any(|d| d.contains("DUPLICATE_FROM_KIN_DONE")),
            "{deltas:?}"
        );
    }
}
